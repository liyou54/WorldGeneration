namespace WorldGen
{
    public class TemperatureSimulation
    {
    }
}