﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("com.alelievr.NodeGraphProcessor.Editor")]