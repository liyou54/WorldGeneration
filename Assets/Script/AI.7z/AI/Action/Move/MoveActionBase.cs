using System;
using SGoap;

namespace AI.Action
{
    public abstract class MoveActionBase:CustomActionBase
    {


    }
}