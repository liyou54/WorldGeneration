using AI.Agent;
using Script.Skill.Effect;
using Battle.Operation;
using Script.Entity;
using SGoap;
using UnityEngine;

namespace AI.Action
{
    public class MoveToSafeAreaAction : MoveActionBase
    {
        private CharacterAgent characterAgent;
        private MoveOperation moveOperation;
        private float safeDistance;

        public override void OnStartPerform()
        {
            Debug.Log("start move to attack action");
            characterAgent = AgentData.Agent as CharacterAgent;
            var targetTrs = characterAgent.Target.Entity.transform;
            var agent = characterAgent.OperationAbleCharacter;
            var dir = (agent.Entity.transform.position - targetTrs.position).normalized;
            if (dir == Vector3.zero )
            {
                var rand  = Random.insideUnitCircle.normalized;
                dir = new Vector3(rand.x, 0, rand.y);
            }
            safeDistance = characterAgent.CharacteSafeDistance;
            moveOperation = new MoveOperation(targetTrs.position + dir * safeDistance, agent.Entity);
            characterAgent.OperationAbleCharacter.AddOperation(moveOperation);
        }

        public override void OnUpdatePerform()
        {
            // if (moveOperation.RunStatus == EAttachToSystemRunStatus.Success)
            // {
            //     characterAgent.States.RemoveState("InDanger");
            //     status = EActionStatus.Success;
            // }
        }
    }
}