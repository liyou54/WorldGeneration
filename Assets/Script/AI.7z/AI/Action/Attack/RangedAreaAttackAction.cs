using AI.Agent;
using Script.Skill.Bullet;
using SGoap;
using UnityEngine;

namespace AI.Action
{
    // 远程范围攻击
    public class RangedAreaAttackAction : AttackBaseAction
    {
        
        public override void OnUpdatePerform()
        {

        }

        public override void OnStartPerform()
        {
        }
    }
}