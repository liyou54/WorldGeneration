using System;
using System.Collections;
using System.Collections.Generic;
using AI.Action;
using AI.Agent;
using Script.Skill.Effect;
using SGoap;
using Sirenix.OdinInspector;
using UnityEngine;


// 普通攻击
public class NormalAttackActionAction : AttackBaseAction
{

    
    public override void OnStartPerform()
    {
    }
    
    public override void OnUpdatePerform()
    {
        
    }

    
    public  void EffectAttack(TargetAbleComponent targetable)
    {
    }
}