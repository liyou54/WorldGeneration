using SGoap;

namespace AI.Action
{
    // 单体治疗攻击
    public class SingleHealingAttackAction:AttackBaseAction
    {
        public override void OnStartPerform()
        {
        }
    }
    
}