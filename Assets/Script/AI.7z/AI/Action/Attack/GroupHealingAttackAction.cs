using SGoap;

namespace AI.Action
{
    // 团队治疗攻击
    public class GroupHealingAttackAction:AttackBaseAction
    {
        public override void OnStartPerform()
        {
            
        }
    }
}