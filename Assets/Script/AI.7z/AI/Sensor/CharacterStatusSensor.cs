namespace AI.Sensor
{
    public class CharacterStatusSensor:SGoap.Sensor
    {
        public override void OnAwake()
        {
            
        }
    }
}